export * from './iot-sensors-view';
