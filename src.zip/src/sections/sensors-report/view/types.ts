export enum ActiveSection {
    UPLOAD_CSV = 'UPLOAD_CSV',
    UPDATE_REPORT = 'UPDATE_REPORT',
}