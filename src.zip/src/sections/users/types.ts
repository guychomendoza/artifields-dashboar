export enum SelectedModal {
    CHANGE_PASSWORD = 'CHANGE_PASSWORD',
    EDIT_USER = 'EDIT_USER',
    DELETE_USER = 'DELETE_USER',
}
